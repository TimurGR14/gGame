package com.mygdx.game.entety;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.settings.Point2D;

public abstract class Entety{

    public abstract void draw(SpriteBatch batch);
    public abstract  void update();
}
