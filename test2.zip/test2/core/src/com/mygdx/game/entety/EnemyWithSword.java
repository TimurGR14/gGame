package com.mygdx.game.entety;

public class EnemyWithSword {
}
